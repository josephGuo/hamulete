// 密码验证 API - 验证前端提交的密码是否与 Vercel 环境变量中的密码匹配
import { setCorsHeaders } from './cors.js';

export default async function handler(req, res) {
  // 设置 CORS 头
  if (setCorsHeaders(req, res)) {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const { password } = req.body || {};
    
    if (!password) {
      return res.status(400).json({ error: 'Password is required' });
    }

    // 从环境变量读取密码（如果设置了）
    const envPassword = process.env.PASSWORD;
    
    if (!envPassword) {
      // 如果环境变量中没有设置密码，返回特殊状态码，让前端知道可以使用本地配置
      return res.status(404).json({ error: 'Password not configured on server, use local config' });
    }

    // 验证密码
    const isValid = password === envPassword;

    if (isValid) {
      // 生成一个临时 token（24小时有效）
      const token = Buffer.from(`${Date.now()}:${Math.random()}`).toString('base64');
      const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24小时

      return res.status(200).json({
        valid: true,
        token: token,
        expiresAt: expiresAt
      });
    } else {
      return res.status(401).json({ error: 'Invalid password' });
    }
  } catch (err) {
    console.error('Password verification error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

